# GuessMyFruit

For the Amazon Alexa Kid Skills Challenge 2017-2018!

The latest app, Guess My Fruit V1.0 developed by UofT Engineering Science students!

Hardware required: Any voice-enabled Alexa device, with the ability to download skills from the Alexa skills store. 

Guess My Fruit is a skill which enables Alexa to guess the fruit you're thinking about. Just think of a fruit, and let Alexa know you're ready. She will ask you a few questions and then guess which fruit you had in mind! There are no accounts, no sign-ups, and no collection of any private information. It is a simple skill which enables kids to engage with a fun game while learning about the wonderful world of fruits!

All content including fruit facts, and any images associated with this skill, are original creations :)
